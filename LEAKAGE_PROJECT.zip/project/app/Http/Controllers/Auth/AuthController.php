<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;

class AuthController extends Controller
{
    public function login()
    {
        return view('auth.login');
    }

    public function register()
    {
        return view('auth.register');
    }

    public function forgotPass()
    {
        return view("auth.forgot-password");
    }

    //call Seedevent
    public function seedEvent()
    {
        Artisan::call('migrate:fresh --seed');
        return response()->json('Succcess');
    }

    //call Optimize Event
    public function optimizeEvent()
    {
        Artisan::call('optimize:clear');
        return response()->json('Succcess');
    }

    //call clear Event
    public function cacheEvent()
    {
        Artisan::call('cache:clear');
        return response()->json('Succcess');
    }
}
