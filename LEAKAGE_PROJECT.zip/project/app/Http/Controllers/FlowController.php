<?php

namespace App\Http\Controllers;

use App\Models\LeakageHistory;
use App\Models\Sensor;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Log;
use GuzzleHttp\Client;
use AfricasTalking\SDK\AfricasTalking;
use App\Models\SmsHistory;
use Exception;

class FlowController extends Controller
{
    //
    public function receiveData(Request $request)
    {
        Log::info('data received');
        $currentWindowTime = Setting::where('key', 'current-window')->first()->value;
        $sensorId = $request->sensorId;
        $sensorValue = $request->value;
        $windowLength = intval(Setting::where('key', 'time-window')->first()->value);

        $data = [
            'sensorId' => $sensorId,
            'value' => $sensorValue,
            'in-time' => Carbon::now(),
            'window-time' => $currentWindowTime,
            'time-diff' => Carbon::now()->diffInSeconds(Carbon::parse($currentWindowTime))
        ];
        Log::info($data);


        $sensor = Sensor::find($sensorId);
        if (!$sensor) {
            return response()->json(['message' => 'Sensor ID ' . $sensorId . ' Not Found']);
        }

        //current window expired?
        $windowDuration = Carbon::now()->diffInSeconds(Carbon::parse($currentWindowTime));
        if ($windowDuration > $windowLength) {
            if (Setting::where('key', 'current-leakage')->first()->value != null) {
                LeakageHistory::create([
                    'time' => Setting::where('key', 'current-window')->first()->value,
                    'leakage' => Setting::where('key', 'current-leakage')->first()->value
                ]);
            }
            Setting::where('key', 'current-window')->first()->update(['value' => Carbon::now()->format('Y-m-d H:i:s')]);
            Setting::where('key', 'current-leakage')->first()->update(['value' => null]);
            $currentWindowTime = Setting::where('key', 'current-window')->first()->value;
        }


        if ($sensor->flowrate == null) {
            $sensor->flowrate = $sensorValue;
            $sensor->in_time = Carbon::now();
            $sensor->save();
        } else {
            if ($sensor->in_time <= $currentWindowTime) {
                $sensor->flowrate = $sensorValue;
                $sensor->in_time = Carbon::now();
                $sensor->save();
            }
        }

        //is first in window
        $currentWindowReadings = Sensor::where('in_time', '>=', $currentWindowTime)->get();

        //is last in window?
        $sensors = Sensor::all();
        if ($currentWindowReadings->count() == $sensors->count()) {
            $mainSensorFlow = $currentWindowReadings->where('type', 'main')->first()->flowrate;
            $clientSensorsFlow = $currentWindowReadings->where('type', 'client')->sum('flowrate');
            $leakage = $mainSensorFlow - $clientSensorsFlow;
            Setting::where('key', 'current-leakage')->first()->update(['value' => strval($leakage)]);
            //send sms grater than threshold
            $threshold = (int) Setting::where('key', 'leakage-threshold')->first()->value;
            if($leakage > $threshold){
                $this->sendSms('There is a leakage of '.$leakage.' L/s in pipe C');
            }
        }
        return response()->json(Setting::where('key', 'current-leakage')->first());
    }

    public function sendSms($message)
    {
        $history = SmsHistory::latest()->first();

        if (!$history) {
            $this->sendSmsR('+255766025562', $message);
            return;
        }else{
            $interval = (int) Setting::where('key', 'sms-interval')->first()->value;
            $curr = Carbon::parse($history->created_at)->diffInSeconds();
            if ($curr < $interval) {
                return 'waiting for '.$interval.'s... currently '.$curr.'s';
            }
            $this->sendSmsR('+255766025562', $message);
        }

    }

    public function sendSmsR($number, $message)
    {

        // Set your app credentials
        $username   = "Rahma";
        $apiKey     = "948a1c10c07d7750b0bef182f0a4e3b43ae9f184d905099e019a7a813f4666f7";

        // Initialize the SDK
        $AT         = new AfricasTalking($username, $apiKey);

        // Get the SMS service
        $sms        = $AT->sms();

        // Set the numbers you want to send to in international format
        $recipients = $number;

        // Set your message
        $message    = $message . '                 ';

        // Set your shortCode or senderId
        $from       = "AFRICASTKNG";

        try {
            // Thats it, hit send and we'll take care of the rest
            $result = $sms->send([
                'to'      => $recipients,
                'message' => $message,
                // 'from'    => $from
            ]);

            SmsHistory::create([
                'message'=>$message
            ]);
            //dd($result);
        } catch (Exception $e) {
            echo "Error: " . $e->getMessage();
        }
    }
}
