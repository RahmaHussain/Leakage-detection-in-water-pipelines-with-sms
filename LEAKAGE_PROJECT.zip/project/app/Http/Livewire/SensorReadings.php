<?php

namespace App\Http\Livewire;

use App\Models\LeakageHistory;
use App\Models\Setting;
use App\Models\User;
use Illuminate\Support\Carbon;
use Livewire\Component;

class SensorReadings extends Component
{

    public $users;
    public $window;
    public $leakage;
    public $leakageTime;


    public function render()
    {
        return view('livewire.sensor-readings');
    }

    public function mount()
    {
        $this->users = User::with('sensor')->where('user_type', 'resident')->get();
        $this->window =  intval(Setting::where('key', 'time-window')->first()->value);
        $latest = LeakageHistory::latest()->first();
        if ($latest) {
            $this->leakageTime = $latest->time;
            $this->leakage = doubleval($latest->leakage) < 0 ? 0 : $latest->leakage;
        }
    }

    public function updateUsage()
    {
        $this->users = User::where('user_type', 'resident')->get();
        $this->window = Setting::where('key', 'time-window')->first()->value;
        $latest = LeakageHistory::latest()->first();
        if ($latest) {
            $this->leakageTime = Carbon::parse($latest->time)->diffForHumans();
            $this->leakage = doubleval($latest->leakage) < 0 ? 0 : $latest->leakage;
        }
    }
}
