<?php

namespace App\Http\Livewire;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Livewire\Component;

class AddUser extends Component
{
     // public $user;
     public $name;
     public $email;
     public $location;
     public $user_type;

     protected $rules = [
         'name'=>['required'],
         'email'=>['required'],
         'location'=>['required'],
         'user_type'=>['required'],
     ];
     public function mount(){
         $this->user_type = 'resident';
     }
     public function save(){
         $this->validate();
         $user = User::create([
             'name' => $this->name,
             'email' => $this->email,
             'location' => $this->location,
             'user_type' => $this->user_type,
             'password' => Hash::make('12345')
         ]);
         return redirect()->route('users');

     }

    public function render()
    {
        return view('livewire.add-user');
    }

    public function deleteUser()
    {
        dd('hello');
        User::find(1)->delete();
        $this->mount();
    }
}
