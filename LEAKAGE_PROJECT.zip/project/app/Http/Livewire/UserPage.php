<?php

namespace App\Http\Livewire;

use App\Models\Setting;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Livewire\Component;

class UserPage extends Component
{
    public $users;
    public $window;



    public function mount(){

        $this->users = User::with('sensor')->where('user_type','resident')->get();
        $this->window = Setting::where('key','time-window')->first()->value;
    }

    public function render()
    {
        return view('livewire.user-page');
    }

    public function updateUsage()
    {
        dd('test');
        $this->users = User::where('user_type','resident')->get();
        $this->window = Setting::where('key','time-window')->first()->value;
    }

    public function deleteUser()
    {
        dd('hello');
        User::find(1)->delete();
        $this->mount();
    }


}
