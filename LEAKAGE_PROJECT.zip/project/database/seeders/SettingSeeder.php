<?php

namespace Database\Seeders;

use App\Models\Setting;
use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        Setting::create([
            'key'=>'time-window',
            'value' => '5',
        ]);

        Setting::create([
            'key'=>'current-window',
            'value' => Carbon::now(),
        ]);

        Setting::create([
            'key'=>'current-leakage',
            'value' => null,
        ]);

        Setting::create([
            'key'=>'leakage-threshold',
            'value' => '2',
        ]);

        Setting::create([
            'key'=>'sms-interval',
            'value' => '60',
        ]);
    }
}
