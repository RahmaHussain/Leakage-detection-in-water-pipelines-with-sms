<?php

namespace Database\Seeders;

use App\Models\Sensor;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SensorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        Sensor::create([
            'type' => 'main',
            'name' => 'Main Sensor'
        ]);

        Sensor::create([
            'user_id' => 2,
            'type' => 'client',
            'name' => 'Client 1 Sensor'
        ]);

        Sensor::create([
            'user_id' => 3,
            'type' => 'client',
            'name' => 'Client 2 Sensor'
        ]);
    }
}
