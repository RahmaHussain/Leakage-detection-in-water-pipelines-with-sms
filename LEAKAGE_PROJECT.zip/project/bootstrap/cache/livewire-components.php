<?php return array (
  'add-user' => 'App\\Http\\Livewire\\AddUser',
  'home-page' => 'App\\Http\\Livewire\\HomePage',
  'sensor-readings' => 'App\\Http\\Livewire\\SensorReadings',
  'user-page' => 'App\\Http\\Livewire\\UserPage',
);